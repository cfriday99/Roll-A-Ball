﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovingWall2 : MonoBehaviour
{

    Vector3 pointA = new Vector3(68.8f, 0f, 0f);
    Vector3 pointB = new Vector3(62.8f, 0f, 0f);
    void Update()
    {
        transform.position = Vector3.Lerp(pointA, pointB, Mathf.PingPong(Time.time, 1));
    }
}
