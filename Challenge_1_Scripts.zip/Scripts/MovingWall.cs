﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovingWall : MonoBehaviour
{

    Vector3 pointA = new Vector3(81.2f, 0f, -5f);
    Vector3 pointB = new Vector3(87.2f, 0f, -5f);
    void Update()
    {
        transform.position = Vector3.Lerp(pointA, pointB, Mathf.PingPong(Time.time, 1));
    }
}
